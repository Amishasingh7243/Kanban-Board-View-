import type { KanbanColumn } from "@/components/KanbanBoard/KanbanBoard.types";

export const getColumnById = (columns: KanbanColumn[], id: string): KanbanColumn | undefined =>
  columns.find(col => col.id === id);

export const getColumnTaskIndex = (column: KanbanColumn, taskId: string): number =>
  column.taskIds.indexOf(taskId);
