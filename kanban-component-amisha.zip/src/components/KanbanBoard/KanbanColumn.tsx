import React, { useState } from "react";
import type { KanbanColumn, KanbanTask } from "./KanbanBoard.types";
import { KanbanCard } from "./KanbanCard";
import { Button } from "@/components/primitives/Button";

interface KanbanColumnProps {
  column: KanbanColumn;
  tasks: KanbanTask[];
  isActiveDrop: boolean;
  draggedTaskId: string | null;
  onAddTask: (columnId: string) => void;
  onEditTask: (task: KanbanTask) => void;
  onDeleteTask: (taskId: string) => void;
  onDragStart: (taskId: string, columnId: string) => void;
  onDragEnter: (columnId: string, index: number) => void;
  onDrop: () => void;
}

export const KanbanColumnComponent: React.FC<KanbanColumnProps> = ({
  column,
  tasks,
  isActiveDrop,
  draggedTaskId,
  onAddTask,
  onEditTask,
  onDeleteTask,
  onDragStart,
  onDragEnter,
  onDrop
}) => {
  const [collapsed, setCollapsed] = useState(false);

  const visibleTasks = tasks;

  return (
    <section
      className={`flex-shrink-0 w-72 max-w-xs bg-neutral-50 border border-neutral-200 rounded-2xl flex flex-col max-h-[80vh] ${
        isActiveDrop ? "ring-2 ring-primary-400" : ""
      }`}
      role="region"
      aria-label={`${column.title} column. ${tasks.length} tasks.`}
    >
      <header className="sticky top-0 z-10 bg-neutral-50 px-3 pt-3 pb-2 border-b border-neutral-200 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div
            className="w-2 h-6 rounded-full"
            style={{ backgroundColor: column.color }}
            aria-hidden="true"
          />
          <div>
            <h3 className="text-sm font-semibold text-neutral-900">
              {column.title}
            </h3>
            <p className="text-[11px] text-neutral-500">
              {tasks.length} task{tasks.length !== 1 ? "s" : ""}{" "}
              {column.maxTasks
                ? `(max ${column.maxTasks})`
                : ""}
            </p>
          </div>
        </div>
        <button
          className="text-xs text-neutral-500 hover:text-neutral-900"
          onClick={() => setCollapsed(prev => !prev)}
          aria-label={collapsed ? "Expand column" : "Collapse column"}
        >
          {collapsed ? "▾" : "▴"}
        </button>
      </header>
      {!collapsed && (
        <div
          className="flex-1 overflow-y-auto px-3 pt-2 pb-3"
          onDragOver={e => e.preventDefault()}
          onDrop={onDrop}
        >
          {visibleTasks.length === 0 && (
            <p className="text-xs text-neutral-500 italic mb-2">
              No tasks yet. Add one below.
            </p>
          )}
          {visibleTasks.map((task, index) => (
            <KanbanCard
              key={task.id}
              task={task}
              columnId={column.id}
              index={index}
              isDragging={draggedTaskId === task.id}
              onEdit={onEditTask}
              onDelete={onDeleteTask}
              onDragStart={onDragStart}
              onDragEnter={onDragEnter}
              onDrop={onDrop}
            />
          ))}
        </div>
      )}
      <footer className="px-3 pb-3 pt-2 border-t border-neutral-200 bg-neutral-50">
        <Button
          variant="secondary"
          className="w-full justify-center"
          onClick={() => onAddTask(column.id)}
        >
          + Add Task
        </Button>
      </footer>
    </section>
  );
};
