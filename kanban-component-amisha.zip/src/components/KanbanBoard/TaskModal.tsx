import React, { useState } from "react";
import type { KanbanColumn, KanbanTask } from "./KanbanBoard.types";
import { Modal } from "@/components/primitives/Modal";
import { Button } from "@/components/primitives/Button";

interface TaskModalProps {
  initialTask?: KanbanTask;
  columns: KanbanColumn[];
  isOpen: boolean;
  onClose: () => void;
  onSave: (task: KanbanTask) => void;
  onDelete?: (taskId: string) => void;
}

export const TaskModal: React.FC<TaskModalProps> = ({
  initialTask,
  columns,
  isOpen,
  onClose,
  onSave,
  onDelete
}) => {
  const [title, setTitle] = useState(initialTask?.title ?? "");
  const [description, setDescription] = useState(initialTask?.description ?? "");
  const [priority, setPriority] = useState<KanbanTask["priority"]>(
    initialTask?.priority ?? "medium"
  );
  const [assignee, setAssignee] = useState(initialTask?.assignee ?? "");
  const [status, setStatus] = useState(initialTask?.status ?? columns[0]?.id ?? "");
  const [tags, setTags] = useState<string>((initialTask?.tags ?? []).join(", "));
  const [dueDate, setDueDate] = useState<string>(
    initialTask?.dueDate ? initialTask.dueDate.toISOString().substring(0, 10) : ""
  );

  const resetAndClose = () => {
    onClose();
  };

  const handleSubmit: React.FormEventHandler = e => {
    e.preventDefault();
    const now = new Date();
    const base: KanbanTask = {
      id: initialTask?.id ?? `task-${now.getTime()}`,
      title: title.trim() || "Untitled task",
      description: description.trim() || undefined,
      priority: priority,
      assignee: assignee.trim() || undefined,
      status,
      tags: tags
        .split(",")
        .map(t => t.trim())
        .filter(Boolean),
      createdAt: initialTask?.createdAt ?? now,
      dueDate: dueDate ? new Date(dueDate) : undefined
    };
    onSave(base);
    resetAndClose();
  };

  const handleDelete = () => {
    if (initialTask && onDelete) {
      onDelete(initialTask.id);
      resetAndClose();
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={resetAndClose}
      title={initialTask ? "Edit Task" : "New Task"}
      description="Update task details below"
    >
      <form className="space-y-3" onSubmit={handleSubmit}>
        <div>
          <label className="block text-xs font-medium text-neutral-700 mb-1">
            Title
          </label>
          <input
            className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500"
            value={title}
            onChange={e => setTitle(e.target.value)}
            required
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-neutral-700 mb-1">
            Description
          </label>
          <textarea
            className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 min-h-[80px]"
            value={description}
            onChange={e => setDescription(e.target.value)}
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Priority
            </label>
            <select
              className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500"
              value={priority}
              onChange={e =>
                setPriority(e.target.value as KanbanTask["priority"])
              }
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="urgent">Urgent</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Status / Column
            </label>
            <select
              className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500"
              value={status}
              onChange={e => setStatus(e.target.value)}
            >
              {columns.map(col => (
                <option key={col.id} value={col.id}>
                  {col.title}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Assignee
            </label>
            <input
              className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500"
              value={assignee}
              onChange={e => setAssignee(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Due date
            </label>
            <input
              type="date"
              className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500"
              value={dueDate}
              onChange={e => setDueDate(e.target.value)}
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-neutral-700 mb-1">
            Tags (comma separated)
          </label>
          <input
            className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500"
            value={tags}
            onChange={e => setTags(e.target.value)}
            placeholder="frontend, feature"
          />
        </div>
        <div className="flex justify-between items-center pt-2">
          {initialTask && onDelete && (
            <Button
              type="button"
              variant="ghost"
              className="text-error-600"
              onClick={handleDelete}
            >
              Delete
            </Button>
          )}
          <div className="ml-auto flex gap-2">
            <Button type="button" variant="ghost" onClick={resetAndClose}>
              Cancel
            </Button>
            <Button type="submit">
              {initialTask ? "Save changes" : "Create task"}
            </Button>
          </div>
        </div>
      </form>
    </Modal>
  );
};
