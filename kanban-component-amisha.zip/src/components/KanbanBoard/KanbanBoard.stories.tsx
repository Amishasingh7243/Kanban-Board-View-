import type { Meta, StoryObj } from "@storybook/react";
import React, { useState } from "react";
import { KanbanBoard } from "./KanbanBoard";
import type { KanbanColumn, KanbanTask } from "./KanbanBoard.types";
import { sampleColumns as baseColumns, sampleTasks as baseTasks } from "./sampleData";

const meta: Meta<typeof KanbanBoard> = {
  title: "Kanban/KanbanBoard",
  component: KanbanBoard,
  parameters: {
    layout: "fullscreen"
  }
};

export default meta;
type Story = StoryObj<typeof KanbanBoard>;

const useBoardState = (initialColumns: KanbanColumn[], initialTasks: Record<string, KanbanTask>) => {
  const [columns, setColumns] = useState<KanbanColumn[]>(initialColumns);
  const [tasks, setTasks] = useState<Record<string, KanbanTask>>(initialTasks);

  const onTaskMove = (taskId: string, fromColumn: string, toColumn: string, newIndex: number) => {
    setColumns(prev => {
      const next = prev.map(col => ({ ...col, taskIds: [...col.taskIds] }));
      const from = next.find(c => c.id === fromColumn);
      const to = next.find(c => c.id === toColumn);
      if (!from || !to) return prev;
      const fromIndex = from.taskIds.indexOf(taskId);
      if (fromIndex !== -1) {
        from.taskIds.splice(fromIndex, 1);
      }
      const safeIndex = Math.min(Math.max(newIndex, 0), to.taskIds.length);
      to.taskIds.splice(safeIndex, 0, taskId);
      return next;
    });

    setTasks(prev => ({
      ...prev,
      [taskId]: { ...prev[taskId], status: toColumn }
    }));
  };

  const onTaskCreate = (columnId: string, task: KanbanTask) => {
    setTasks(prev => ({ ...prev, [task.id]: task }));
    setColumns(prev =>
      prev.map(col =>
        col.id === columnId ? { ...col, taskIds: [...col.taskIds, task.id] } : col
      )
    );
  };

  const onTaskUpdate = (taskId: string, updates: Partial<KanbanTask>) => {
    setTasks(prev => ({
      ...prev,
      [taskId]: { ...prev[taskId], ...updates }
    }));
  };

  const onTaskDelete = (taskId: string) => {
    setColumns(prev =>
      prev.map(col => ({
        ...col,
        taskIds: col.taskIds.filter(id => id !== taskId)
      }))
    );
    setTasks(prev => {
      const copy = { ...prev };
      delete copy[taskId];
      return copy;
    });
  };

  return { columns, tasks, onTaskMove, onTaskCreate, onTaskUpdate, onTaskDelete };
};

export const Default: Story = {
  render: () => {
    const { columns, tasks, ...handlers } = useBoardState(baseColumns, baseTasks);
    return (
      <div className="min-h-screen bg-neutral-50 p-4">
        <KanbanBoard columns={columns} tasks={tasks} {...handlers} />
      </div>
    );
  }
};

export const Empty: Story = {
  render: () => {
    const emptyColumns: KanbanColumn[] = baseColumns.map(col => ({
      ...col,
      taskIds: []
    }));
    const { columns, tasks, ...handlers } = useBoardState(emptyColumns, {});
    return (
      <div className="min-h-screen bg-neutral-50 p-4">
        <KanbanBoard columns={columns} tasks={tasks} {...handlers} />
      </div>
    );
  }
};

export const LargeDataset: Story = {
  render: () => {
    const manyTasks: Record<string, KanbanTask> = { ...baseTasks };
    const manyColumns: KanbanColumn[] = baseColumns.map(col => ({
      ...col,
      taskIds: [...col.taskIds]
    }));
    let counter = 6;
    for (let i = 0; i < 40; i++) {
      const id = `task-${counter++}`;
      const column = manyColumns[i % manyColumns.length];
      column.taskIds.push(id);
      manyTasks[id] = {
        id,
        title: `Generated task #${i + 1}`,
        status: column.id,
        createdAt: new Date(2024, 0, 12),
        priority: (["low", "medium", "high", "urgent"] as const)[i % 4],
        assignee: i % 2 === 0 ? "John Doe" : "Jane Smith",
        tags: ["auto"]
      };
    }
    const { columns, tasks, ...handlers } = useBoardState(manyColumns, manyTasks);
    return (
      <div className="min-h-screen bg-neutral-50 p-4">
        <KanbanBoard columns={columns} tasks={tasks} {...handlers} />
      </div>
    );
  }
};

export const MobileView: Story = {
  parameters: {
    viewport: {
      defaultViewport: "iphonex"
    }
  },
  render: () => {
    const { columns, tasks, ...handlers } = useBoardState(baseColumns, baseTasks);
    return (
      <div className="min-h-screen bg-neutral-50 p-2">
        <KanbanBoard columns={columns} tasks={tasks} {...handlers} />
      </div>
    );
  }
};

export const InteractivePlayground: Story = {
  render: () => {
    const { columns, tasks, ...handlers } = useBoardState(baseColumns, baseTasks);
    return (
      <div className="min-h-screen bg-neutral-50 p-4">
        <KanbanBoard columns={columns} tasks={tasks} {...handlers} />
      </div>
    );
  }
};
