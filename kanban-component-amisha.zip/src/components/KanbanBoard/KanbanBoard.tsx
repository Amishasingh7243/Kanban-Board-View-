import React, { useMemo, useState } from "react";
import type { KanbanViewProps, KanbanTask } from "./KanbanBoard.types";
import { useKanbanBoard } from "@/hooks/useKanbanBoard";
import { useDragAndDrop } from "@/hooks/useDragAndDrop";
import { KanbanColumnComponent } from "./KanbanColumn";
import { TaskModal } from "./TaskModal";
import { getColumnById, getColumnTaskIndex } from "@/utils/column.utils";

export const KanbanBoard: React.FC<KanbanViewProps> = ({
  columns,
  tasks,
  onTaskMove,
  onTaskCreate,
  onTaskUpdate,
  onTaskDelete
}) => {
  const { columns: orderedColumns, getTasksForColumn } = useKanbanBoard({
    columns,
    tasks
  });
  const dragState = useDragAndDrop();
  const [editingTask, setEditingTask] = useState<KanbanTask | undefined>();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalColumnId, setModalColumnId] = useState<string | null>(null);

  const handleAddTask = (columnId: string) => {
    setModalColumnId(columnId);
    setEditingTask(undefined);
    setIsModalOpen(true);
  };

  const handleEditTask = (task: KanbanTask) => {
    setEditingTask(task);
    setModalColumnId(task.status);
    setIsModalOpen(true);
  };

  const handleSaveTask = (task: KanbanTask) => {
    const existing = tasks[task.id];
    if (existing) {
      onTaskUpdate(task.id, task);
      if (existing.status !== task.status) {
        const from = existing.status;
        const to = task.status;
        const toColumn = getColumnById(columns, to);
        const newIndex = toColumn ? toColumn.taskIds.length : 0;
        onTaskMove(task.id, from, to, newIndex);
      }
    } else {
      const columnId = task.status;
      onTaskCreate(columnId, task);
    }
  };

  const handleDeleteTask = (taskId: string) => {
    onTaskDelete(taskId);
  };

  const handleDrop = () => {
    const { draggedTaskId, fromColumnId, overColumnId, overIndex } = dragState;
    if (!draggedTaskId || !fromColumnId || !overColumnId || overIndex == null) {
      dragState.endDrag();
      return;
    }
    const sourceColumn = getColumnById(columns, fromColumnId);
    const destinationColumn = getColumnById(columns, overColumnId);
    if (!sourceColumn || !destinationColumn) {
      dragState.endDrag();
      return;
    }
    const fromIndex = getColumnTaskIndex(sourceColumn, draggedTaskId);
    const safeIndex = Math.max(0, Math.min(overIndex, destinationColumn.taskIds.length));
    onTaskMove(draggedTaskId, fromColumnId, overColumnId, safeIndex);
    dragState.endDrag();
  };

  const isEmpty = useMemo(
    () => orderedColumns.every(col => col.taskIds.length === 0),
    [orderedColumns]
  );

  return (
    <div className="relative">
      {isEmpty && (
        <p className="mb-2 text-sm text-neutral-500">
          Empty board – start by creating your first task.
        </p>
      )}
      <div
        className="flex gap-4 overflow-x-auto pb-4 pt-2"
        role="list"
        aria-label="Kanban board"
      >
        {orderedColumns.map(column => {
          const columnTasks = getTasksForColumn(column.id);
          const isDropTarget =
            dragState.overColumnId === column.id ||
            (!dragState.overColumnId && dragState.fromColumnId === column.id);
          return (
            <KanbanColumnComponent
              key={column.id}
              column={column}
              tasks={columnTasks}
              isActiveDrop={isDropTarget}
              draggedTaskId={dragState.draggedTaskId}
              onAddTask={handleAddTask}
              onEditTask={handleEditTask}
              onDeleteTask={handleDeleteTask}
              onDragStart={dragState.startDrag}
              onDragEnter={dragState.updateOver}
              onDrop={handleDrop}
            />
          );
        })}
      </div>
      {modalColumnId && (
        <TaskModal
          isOpen={isModalOpen}
          initialTask={editingTask}
          onClose={() => setIsModalOpen(false)}
          columns={orderedColumns}
          onSave={handleSaveTask}
          onDelete={editingTask ? handleDeleteTask : undefined}
        />
      )}
    </div>
  );
};
