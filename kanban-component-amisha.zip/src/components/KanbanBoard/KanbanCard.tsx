import React from "react";
import type { KanbanTask } from "./KanbanBoard.types";
import { Avatar } from "@/components/primitives/Avatar";
import { formatDate, getPriorityColor, isOverdue } from "@/utils/task.utils";

interface KanbanCardProps {
  task: KanbanTask;
  columnId: string;
  index: number;
  isDragging: boolean;
  onEdit: (task: KanbanTask) => void;
  onDelete: (taskId: string) => void;
  onDragStart: (taskId: string, columnId: string) => void;
  onDragEnter: (columnId: string, index: number) => void;
  onDrop: () => void;
}

export const KanbanCard: React.FC<KanbanCardProps> = ({
  task,
  columnId,
  index,
  isDragging,
  onEdit,
  onDelete,
  onDragStart,
  onDragEnter,
  onDrop
}) => {
  const priorityClasses = task.priority ? getPriorityColor(task.priority) : "";
  const handleKeyDown: React.KeyboardEventHandler<HTMLDivElement> = e => {
    if (e.key === "Enter") {
      onEdit(task);
    }
  };

  return (
    <div
      className={`bg-white border border-neutral-200 rounded-xl p-3 shadow-card hover:shadow-card-hover transition-shadow cursor-grab active:cursor-grabbing mb-2 ${priorityClasses} ${
        isDragging ? "opacity-70" : ""
      }`}
      draggable
      onDragStart={e => {
        e.dataTransfer.effectAllowed = "move";
        onDragStart(task.id, columnId);
      }}
      onDragEnter={() => onDragEnter(columnId, index)}
      onDrop={onDrop}
      onDragOver={e => e.preventDefault()}
      role="button"
      tabIndex={0}
      aria-label={`${task.title}. Status: ${task.status}. Priority: ${task.priority ?? "none"}. Press enter to edit.`}
      aria-grabbed={isDragging}
      onKeyDown={handleKeyDown}
    >
      <div className="flex items-start justify-between gap-2 mb-2">
        <h4 className="font-medium text-sm text-neutral-900 line-clamp-2">
          {task.title}
        </h4>
        {task.priority && (
          <span className="text-[11px] px-2 py-0.5 rounded-full bg-neutral-100 capitalize">
            {task.priority}
          </span>
        )}
      </div>
      {task.description && (
        <p className="text-xs text-neutral-600 mb-2 line-clamp-2">
          {task.description}
        </p>
      )}
      <div className="flex items-center justify-between mt-1">
        <div className="flex flex-wrap gap-1">
          {task.tags?.slice(0, 3).map(tag => (
            <span
              key={tag}
              className="text-[11px] bg-neutral-100 px-2 py-0.5 rounded-full text-neutral-700"
            >
              {tag}
            </span>
          ))}
        </div>
        {task.assignee && <Avatar name={task.assignee} />}
      </div>
      {task.dueDate && (
        <div
          className={`text-[11px] mt-2 ${
            isOverdue(task.dueDate) ? "text-red-600" : "text-neutral-500"
          }`}
        >
          Due: {formatDate(task.dueDate)}
        </div>
      )}
      <div className="flex justify-end gap-2 mt-2">
        <button
          className="text-[11px] text-neutral-500 hover:text-neutral-800 underline-offset-2 hover:underline"
          onClick={() => onEdit(task)}
        >
          Edit
        </button>
        <button
          className="text-[11px] text-error-600 hover:text-error-700 underline-offset-2 hover:underline"
          onClick={() => onDelete(task.id)}
        >
          Delete
        </button>
      </div>
    </div>
  );
};
