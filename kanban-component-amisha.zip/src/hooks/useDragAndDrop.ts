import { useCallback, useState } from "react";

interface DragState {
  isDragging: boolean;
  draggedTaskId: string | null;
  fromColumnId: string | null;
  overColumnId: string | null;
  overIndex: number | null;
}

export const useDragAndDrop = () => {
  const [state, setState] = useState<DragState>({
    isDragging: false,
    draggedTaskId: null,
    fromColumnId: null,
    overColumnId: null,
    overIndex: null
  });

  const startDrag = useCallback((taskId: string, fromColumnId: string) => {
    setState(prev => ({
      ...prev,
      isDragging: true,
      draggedTaskId: taskId,
      fromColumnId
    }));
  }, []);

  const updateOver = useCallback((columnId: string, index: number) => {
    setState(prev => ({
      ...prev,
      overColumnId: columnId,
      overIndex: index
    }));
  }, []);

  const endDrag = useCallback(() => {
    setState({
      isDragging: false,
      draggedTaskId: null,
      fromColumnId: null,
      overColumnId: null,
      overIndex: null
    });
  }, []);

  return {
    ...state,
    startDrag,
    updateOver,
    endDrag
  };
};
