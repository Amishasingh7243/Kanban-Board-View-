import { useMemo } from "react";
import type { KanbanColumn, KanbanTask } from "@/components/KanbanBoard/KanbanBoard.types";

interface UseKanbanBoardArgs {
  columns: KanbanColumn[];
  tasks: Record<string, KanbanTask>;
}

export const useKanbanBoard = ({ columns, tasks }: UseKanbanBoardArgs) => {
  const orderedColumns = useMemo(() => columns, [columns]);

  const getTasksForColumn = (columnId: string): KanbanTask[] => {
    const column = orderedColumns.find(col => col.id === columnId);
    if (!column) return [];
    return column.taskIds
      .map(id => tasks[id])
      .filter((t): t is KanbanTask => Boolean(t));
  };

  return {
    columns: orderedColumns,
    getTasksForColumn
  };
};
